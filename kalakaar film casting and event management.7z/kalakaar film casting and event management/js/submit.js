// Submit page specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initSubmitForm();
    initFileUploads();
    initModal();
    initFormValidation();
    initProgressIndicator();
});

// Initialize the submit form
function initSubmitForm() {
    const profileForm = document.getElementById('profileForm');
    
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (validateForm()) {
                submitProfile();
            }
        });
    }
}

// Form validation
function validateForm() {
    let isValid = true;
    const requiredFields = document.querySelectorAll('[required]');
    
    // Reset all error states
    document.querySelectorAll('.form-group').forEach(group => {
        group.classList.remove('error', 'success');
    });
    
    // Validate required fields
    requiredFields.forEach(field => {
        const formGroup = field.closest('.form-group');
        
        if (!field.value.trim()) {
            formGroup.classList.add('error');
            isValid = false;
        } else {
            formGroup.classList.add('success');
        }
    });
    
    // Validate email
    const emailField = document.getElementById('email');
    if (emailField && emailField.value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailField.value)) {
            emailField.closest('.form-group').classList.add('error');
            isValid = false;
        }
    }
    
    // Validate phone
    const phoneField = document.getElementById('phone');
    if (phoneField && phoneField.value) {
        const phoneRegex = /^[\d\s\-\+\(\)]+$/;
        if (!phoneRegex.test(phoneField.value) || phoneField.value.replace(/\D/g, '').length < 10) {
            phoneField.closest('.form-group').classList.add('error');
            isValid = false;
        }
    }
    
    // Validate date of birth (must be at least 18 years old)
    const dobField = document.getElementById('dob');
    if (dobField && dobField.value) {
        const dob = new Date(dobField.value);
        const today = new Date();
        const age = Math.floor((today - dob) / (365.25 * 24 * 60 * 60 * 1000));
        
        if (age < 18) {
            dobField.closest('.form-group').classList.add('error');
            showNotification('You must be at least 18 years old to submit a profile', 'error');
            isValid = false;
        }
    }
    
    // Validate file sizes
    const profilePhoto = document.getElementById('profilePhoto');
    if (profilePhoto && profilePhoto.files[0]) {
        if (profilePhoto.files[0].size > 5 * 1024 * 1024) { // 5MB limit
            profilePhoto.closest('.form-group').classList.add('error');
            showNotification('Profile photo must be less than 5MB', 'error');
            isValid = false;
        }
    }
    
    // Validate work type checkboxes (at least one must be selected)
    const workTypeCheckboxes = document.querySelectorAll('input[name="workType"]:checked');
    if (workTypeCheckboxes.length === 0) {
        const workTypeGroup = document.querySelector('input[name="workType"]').closest('.form-group');
        workTypeGroup.classList.add('error');
        showNotification('Please select at least one preferred work type', 'error');
        isValid = false;
    }
    
    // Validate terms checkbox
    const termsCheckbox = document.getElementById('terms');
    if (!termsCheckbox || !termsCheckbox.checked) {
        termsCheckbox.closest('.form-group').classList.add('error');
        showNotification('Please accept the terms and conditions', 'error');
        isValid = false;
    }
    
    if (!isValid) {
        // Scroll to first error
        const firstError = document.querySelector('.form-group.error');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    
    return isValid;
}

// Initialize file uploads with preview
function initFileUploads() {
    // Profile photo upload
    const profilePhotoInput = document.getElementById('profilePhoto');
    const profilePhotoPreview = document.getElementById('profilePhotoPreview');
    
    if (profilePhotoInput && profilePhotoPreview) {
        profilePhotoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    profilePhotoPreview.src = e.target.result;
                    profilePhotoPreview.classList.add('show');
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Portfolio photos upload
    const portfolioPhotosInput = document.getElementById('portfolioPhotos');
    const portfolioPreviewContainer = document.getElementById('portfolioPreviewContainer');
    
    if (portfolioPhotosInput && portfolioPreviewContainer) {
        portfolioPhotosInput.addEventListener('change', function(e) {
            portfolioPreviewContainer.innerHTML = '';
            
            Array.from(e.target.files).forEach((file, index) => {
                if (file.type.startsWith('image/')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.className = 'file-preview show';
                        img.alt = `Portfolio Photo ${index + 1}`;
                        portfolioPreviewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });
    }
}

// Initialize modal
function initModal() {
    const modal = document.getElementById('successModal');
    const closeModal = document.querySelector('.close-modal');
    
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            modal.classList.remove('show');
        });
    }
    
    // Close modal when clicking outside
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.remove('show');
            }
        });
    }
    
    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal && modal.classList.contains('show')) {
            modal.classList.remove('show');
        }
    });
}

// Submit profile to backend
function submitProfile() {
    const profileForm = document.getElementById('profileForm');
    const submitBtn = profileForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.textContent;
    
    // Show loading state
    showLoading(submitBtn, 'Submitting...');
    profileForm.classList.add('loading');
    
    // Create FormData for file uploads
    const formData = new FormData(profileForm);
    
    // Add work type checkboxes as array
    const workTypes = [];
    document.querySelectorAll('input[name="workType"]:checked').forEach(checkbox => {
        workTypes.push(checkbox.value);
    });
    formData.set('workTypes', workTypes.join(','));
    
    // Submit to backend
    fetch('php/submit-profile-db.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccessModal();
            profileForm.reset();
            clearFilePreviews();
            updateProgress(0);
        } else {
            showNotification(data.message || 'Failed to submit profile. Please try again.', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('Network error. Please check your connection and try again.', 'error');
    })
    .finally(() => {
        // Reset loading state
        hideLoading(submitBtn, originalText);
        profileForm.classList.remove('loading');
    });
}

// Show success modal
function showSuccessModal() {
    const modal = document.getElementById('successModal');
    if (modal) {
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}

// Clear file previews
function clearFilePreviews() {
    const previews = document.querySelectorAll('.file-preview');
    previews.forEach(preview => {
        preview.src = '';
        preview.classList.remove('show');
    });
    
    const portfolioPreviewContainer = document.getElementById('portfolioPreviewContainer');
    if (portfolioPreviewContainer) {
        portfolioPreviewContainer.innerHTML = '';
    }
}

// Initialize form validation on input
function initFormValidation() {
    const inputs = document.querySelectorAll('input, select, textarea');
    
    inputs.forEach(input => {
        input.addEventListener('blur', function() {
            validateField(this);
        });
        
        input.addEventListener('input', function() {
            if (this.closest('.form-group').classList.contains('error')) {
                validateField(this);
            }
        });
    });
}

// Validate individual field
function validateField(field) {
    const formGroup = field.closest('.form-group');
    
    if (field.hasAttribute('required') && !field.value.trim()) {
        formGroup.classList.add('error');
        formGroup.classList.remove('success');
        return false;
    } else {
        formGroup.classList.remove('error');
        
        if (field.value.trim()) {
            formGroup.classList.add('success');
        } else {
            formGroup.classList.remove('success');
        }
        
        // Special validations
        if (field.type === 'email' && field.value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(field.value)) {
                formGroup.classList.add('error');
                formGroup.classList.remove('success');
                return false;
            }
        }
        
        if (field.type === 'tel' && field.value) {
            const phoneRegex = /^[\d\s\-\+\(\)]+$/;
            if (!phoneRegex.test(field.value) || field.value.replace(/\D/g, '').length < 10) {
                formGroup.classList.add('error');
                formGroup.classList.remove('success');
                return false;
            }
        }
        
        return true;
    }
}

// Initialize progress indicator
function initProgressIndicator() {
    const formSections = document.querySelectorAll('.form-section');
    const totalSections = formSections.length;
    
    // Create progress bar
    const progressBar = document.createElement('div');
    progressBar.className = 'progress-bar';
    progressBar.innerHTML = '<div class="progress-fill"></div>';
    
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.insertBefore(progressBar, profileForm.firstChild);
    }
    
    // Update progress on scroll
    updateProgress();
    window.addEventListener('scroll', updateProgress);
    
    // Update progress on input
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('input', updateProgress);
    });
}

// Update progress indicator
function updateProgress() {
    const totalFields = document.querySelectorAll('input[required], select[required], textarea[required]').length;
    const filledFields = document.querySelectorAll('input[required]:valid, select[required]:valid, textarea[required]:valid').length;
    
    const progress = totalFields > 0 ? (filledFields / totalFields) * 100 : 0;
    const progressFill = document.querySelector('.progress-fill');
    
    if (progressFill) {
        progressFill.style.width = progress + '%';
    }
}

// Show loading state
function showLoading(element, text) {
    element.disabled = true;
    element.textContent = text;
    element.classList.add('loading');
}

// Hide loading state
function hideLoading(element, originalText) {
    element.disabled = false;
    element.textContent = originalText;
    element.classList.remove('loading');
}

// Show notification (reuses function from main script)
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 300px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    `;
    
    // Set background color based on type
    switch(type) {
        case 'success':
            notification.style.backgroundColor = '#28a745';
            break;
        case 'error':
            notification.style.backgroundColor = '#dc3545';
            break;
        default:
            notification.style.backgroundColor = '#007bff';
    }
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

// Auto-save functionality
function initAutoSave() {
    const form = document.getElementById('profileForm');
    const autoSaveInterval = 30000; // 30 seconds
    
    // Load saved data on page load
    loadSavedData();
    
    // Auto-save periodically
    setInterval(() => {
        saveFormData();
    }, autoSaveInterval);
    
    // Save on input
    const inputs = form.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('input', debounce(saveFormData, 1000));
    });
}

// Save form data to localStorage
function saveFormData() {
    const form = document.getElementById('profileForm');
    const formData = new FormData(form);
    const data = {};
    
    for (let [key, value] of formData.entries()) {
        data[key] = value;
    }
    
    // Handle checkboxes separately
    const checkboxes = form.querySelectorAll('input[type="checkbox"]');
    checkboxes.forEach(checkbox => {
        data[checkbox.name] = checkbox.checked;
    });
    
    localStorage.setItem('kalakaar_profile_draft', JSON.stringify(data));
}

// Load saved data from localStorage
function loadSavedData() {
    const savedData = localStorage.getItem('kalakaar_profile_draft');
    
    if (savedData) {
        try {
            const data = JSON.parse(savedData);
            const form = document.getElementById('profileForm');
            
            // Restore input values
            Object.keys(data).forEach(key => {
                const field = form.querySelector(`[name="${key}"]`);
                if (field) {
                    if (field.type === 'checkbox') {
                        field.checked = data[key];
                    } else {
                        field.value = data[key];
                    }
                }
            });
            
            // Update progress
            updateProgress();
            
            // Show notification
            showNotification('Previous form data restored', 'info');
        } catch (error) {
            console.error('Error loading saved data:', error);
        }
    }
}

// Clear saved data
function clearSavedData() {
    localStorage.removeItem('kalakaar_profile_draft');
}

// Debounce function for auto-save
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize auto-save (optional - can be enabled if needed)
// initAutoSave();
