<?php
require_once __DIR__ . '/includes/auth.php';
require_admin();

$db = getDB();

$flash_success = '';
$flash_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf($token)) {
        $flash_error = 'Security check failed. Please refresh and try again.';
    } else {
        try {
            if (($_POST['action'] ?? '') === 'update_profile_status') {
                $id = (int)($_POST['id'] ?? 0);
                $status = (string)($_POST['status'] ?? 'pending_review');
                $allowed = ['pending_review','under_review','approved','rejected','archived'];
                if ($id > 0 && in_array($status, $allowed, true)) {
                    $db->update('profiles', ['status' => $status], 'id = ?', [$id]);
                    $flash_success = 'Profile status updated.';
                }
            }

            if (($_POST['action'] ?? '') === 'update_contact_status') {
                $id = (int)($_POST['id'] ?? 0);
                $status = (string)($_POST['status'] ?? 'new');
                $allowed = ['new','read','replied','archived'];
                if ($id > 0 && in_array($status, $allowed, true)) {
                    $db->update('contact_submissions', ['status' => $status], 'id = ?', [$id]);
                    $flash_success = 'Contact status updated.';
                }
            }
        } catch (Exception $e) {
            $flash_error = 'Update failed.';
        }
    }
}

$stats = [
    'profiles_total' => 0,
    'profiles_pending' => 0,
    'profiles_under' => 0,
    'profiles_approved' => 0,
    'contacts_new' => 0
];

try {
    $stats['profiles_total'] = (int)$db->query('SELECT COUNT(*) c FROM profiles')->fetch()['c'];
    $stats['profiles_pending'] = (int)$db->query("SELECT COUNT(*) c FROM profiles WHERE status = 'pending_review'")->fetch()['c'];
    $stats['profiles_under'] = (int)$db->query("SELECT COUNT(*) c FROM profiles WHERE status = 'under_review'")->fetch()['c'];
    $stats['profiles_approved'] = (int)$db->query("SELECT COUNT(*) c FROM profiles WHERE status = 'approved'")->fetch()['c'];
    $stats['contacts_new'] = (int)$db->query("SELECT COUNT(*) c FROM contact_submissions WHERE status = 'new'")->fetch()['c'];
} catch (Exception $e) {
}

$profiles = [];
$contacts = [];

try {
    $profiles = $db->query('SELECT id, submission_id, first_name, last_name, category, location, status, submission_date FROM profiles ORDER BY submission_date DESC LIMIT 20')->fetchAll();
    $contacts = $db->query('SELECT id, name, email, phone, status, created_at FROM contact_submissions ORDER BY created_at DESC LIMIT 20')->fetchAll();
} catch (Exception $e) {
}

$user = admin_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Dashboard | Kalakaar</title>
    <link rel="stylesheet" href="assets/admin.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="topbar">
        <div class="wrap">
            <div class="brand">Kalakaar Admin</div>
            <div class="nav">
                <a href="settings.php">Website Settings</a>
                <a href="password.php">Change Password</a>
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>

    <div class="wrap">
        <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:14px;">
            <div>
                <h2 style="margin:0;">Dashboard</h2>
                <div class="muted">Signed in as <?php echo h($user['full_name'] ?? $user['username']); ?> (<?php echo h($user['role']); ?>)</div>
            </div>
            <div class="muted"><a href="../index.html">View Website</a></div>
        </div>

        <?php if ($flash_error): ?>
            <div class="error"><?php echo h($flash_error); ?></div>
        <?php elseif ($flash_success): ?>
            <div class="success"><?php echo h($flash_success); ?></div>
        <?php endif; ?>

        <div class="stats" style="margin-bottom:16px;">
            <div class="stat"><div class="k">Total Profiles</div><div class="v"><?php echo (int)$stats['profiles_total']; ?></div></div>
            <div class="stat"><div class="k">Pending Review</div><div class="v"><?php echo (int)$stats['profiles_pending']; ?></div></div>
            <div class="stat"><div class="k">Under Review</div><div class="v"><?php echo (int)$stats['profiles_under']; ?></div></div>
            <div class="stat"><div class="k">Approved</div><div class="v"><?php echo (int)$stats['profiles_approved']; ?></div></div>
        </div>

        <div class="grid">
            <div class="col-12">
                <div class="card">
                    <div class="row" style="justify-content:space-between;align-items:center;">
                        <h3 style="margin:0;">Latest Talent Profiles</h3>
                        <div class="muted">Showing last 20</div>
                    </div>
                    <div style="overflow:auto;margin-top:10px;">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Submission</th>
                                    <th>Name</th>
                                    <th>Category</th>
                                    <th>Location</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($profiles as $p): ?>
                                    <tr>
                                        <td><?php echo h($p['submission_id']); ?></td>
                                        <td><?php echo h($p['first_name'] . ' ' . $p['last_name']); ?></td>
                                        <td><?php echo h($p['category']); ?></td>
                                        <td><?php echo h($p['location']); ?></td>
                                        <td><span class="badge <?php echo h(status_badge_class_profile($p['status'])); ?>"><?php echo h($p['status']); ?></span></td>
                                        <td><?php echo h($p['submission_date']); ?></td>
                                        <td>
                                            <form method="post" class="row" style="gap:8px;">
                                                <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>" />
                                                <input type="hidden" name="action" value="update_profile_status" />
                                                <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>" />
                                                <select class="input" name="status" style="max-width:190px;padding:10px;">
                                                    <?php foreach (['pending_review','under_review','approved','rejected','archived'] as $s): ?>
                                                        <option value="<?php echo h($s); ?>" <?php echo $p['status']===$s?'selected':''; ?>><?php echo h($s); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <button class="btn btn-primary" type="submit">Update</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($profiles)): ?>
                                    <tr><td colspan="7" class="muted">No profiles yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="card" style="margin-top:16px;">
                    <div class="row" style="justify-content:space-between;align-items:center;">
                        <h3 style="margin:0;">Latest Contact Messages</h3>
                        <div class="muted">New: <?php echo (int)$stats['contacts_new']; ?></div>
                    </div>
                    <div style="overflow:auto;margin-top:10px;">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($contacts as $c): ?>
                                    <tr>
                                        <td><?php echo h($c['name']); ?></td>
                                        <td><?php echo h($c['email']); ?></td>
                                        <td><?php echo h($c['phone']); ?></td>
                                        <td><span class="badge <?php echo h(status_badge_class_contact($c['status'])); ?>"><?php echo h($c['status']); ?></span></td>
                                        <td><?php echo h($c['created_at']); ?></td>
                                        <td>
                                            <form method="post" class="row" style="gap:8px;">
                                                <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>" />
                                                <input type="hidden" name="action" value="update_contact_status" />
                                                <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>" />
                                                <select class="input" name="status" style="max-width:190px;padding:10px;">
                                                    <?php foreach (['new','read','replied','archived'] as $s): ?>
                                                        <option value="<?php echo h($s); ?>" <?php echo $c['status']===$s?'selected':''; ?>><?php echo h($s); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <button class="btn btn-primary" type="submit">Update</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($contacts)): ?>
                                    <tr><td colspan="6" class="muted">No messages yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
