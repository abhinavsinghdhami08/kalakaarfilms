<?php
require_once __DIR__ . '/includes/auth.php';

$db = getDB();

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!verify_csrf($token)) {
        $error = 'Security check failed. Please refresh and try again.';
    } else {
        $identifier = trim($_POST['identifier'] ?? '');
        $current = (string)($_POST['current_password'] ?? '');
        $new = (string)($_POST['new_password'] ?? '');
        $confirm = (string)($_POST['confirm_password'] ?? '');

        if ($identifier === '' || $current === '' || $new === '' || $confirm === '') {
            $error = 'All fields are required.';
        } elseif ($new !== $confirm) {
            $error = 'New passwords do not match.';
        } elseif (strlen($new) < 8) {
            $error = 'New password must be at least 8 characters.';
        } else {
            try {
                $stmt = $db->query('SELECT id, password_hash, is_active FROM admin_users WHERE (username = ? OR email = ?) LIMIT 1', [$identifier, $identifier]);
                $user = $stmt->fetch();

                if (!$user || (int)$user['is_active'] !== 1) {
                    $error = 'Invalid user.';
                } elseif (!password_verify($current, $user['password_hash'])) {
                    $error = 'Current password is incorrect.';
                } else {
                    $hash = password_hash($new, PASSWORD_BCRYPT);
                    $db->update('admin_users', ['password_hash' => $hash], 'id = ?', [(int)$user['id']]);
                    $success = 'Password updated successfully. You can login now.';
                }
            } catch (Exception $e) {
                $error = 'Failed to update password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Change Password | Kalakaar Admin</title>
    <link rel="stylesheet" href="assets/admin.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <div class="topbar">
        <div class="wrap">
            <div class="brand">Kalakaar Admin</div>
            <div class="nav">
                <a href="login.php">Login</a>
                <a href="../index.html">Website</a>
            </div>
        </div>
    </div>

    <div class="wrap">
        <div class="card" style="max-width:620px;margin:30px auto;">
            <h2 style="margin-top:0;">Change Admin Password</h2>
            <p class="muted">Use this to change the password for an existing admin user.</p>

            <?php if ($error): ?>
                <div class="error"><?php echo h($error); ?></div>
            <?php elseif ($success): ?>
                <div class="success"><?php echo h($success); ?></div>
            <?php endif; ?>

            <form method="post" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>" />
                <div style="margin-bottom:12px;">
                    <label class="muted" for="identifier">Username or Email</label>
                    <input class="input" id="identifier" name="identifier" type="text" required />
                </div>
                <div style="margin-bottom:12px;">
                    <label class="muted" for="current_password">Current Password</label>
                    <input class="input" id="current_password" name="current_password" type="password" required />
                </div>
                <div style="margin-bottom:12px;">
                    <label class="muted" for="new_password">New Password</label>
                    <input class="input" id="new_password" name="new_password" type="password" required />
                </div>
                <div style="margin-bottom:16px;">
                    <label class="muted" for="confirm_password">Confirm New Password</label>
                    <input class="input" id="confirm_password" name="confirm_password" type="password" required />
                </div>
                <div class="row" style="justify-content:space-between;align-items:center;">
                    <button class="btn btn-primary" type="submit">Update Password</button>
                    <a class="btn btn-secondary" href="login.php" style="display:inline-flex;align-items:center;justify-content:center;">Back</a>
                </div>
            </form>

            <div style="margin-top:14px;" class="muted">
                If you imported the provided <code>database.sql</code>, the default admin user is:
                <div style="margin-top:8px;">
                    <strong>username:</strong> <code>admin</code><br>
                    <strong>password:</strong> <code>password</code>
                </div>
                Change it immediately.
            </div>
        </div>
    </div>
</body>
</html>
