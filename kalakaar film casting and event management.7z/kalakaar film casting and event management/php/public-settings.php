<?php
define('API_MODE', true);
require_once __DIR__ . '/../config/database.php';

try {
    $db = getDB();
    $rows = $db->query('SELECT setting_key, setting_value, setting_type FROM settings WHERE is_public = 1')->fetchAll();

    $out = [];
    foreach ($rows as $r) {
        $k = (string)$r['setting_key'];
        $t = (string)$r['setting_type'];
        $v = $r['setting_value'];

        if ($t === 'number') {
            $out[$k] = (float)$v;
        } elseif ($t === 'boolean') {
            $out[$k] = ((string)$v === '1' || strtolower((string)$v) === 'true');
        } elseif ($t === 'json') {
            $decoded = json_decode((string)$v, true);
            $out[$k] = $decoded === null ? $v : $decoded;
        } else {
            $out[$k] = (string)$v;
        }
    }

    jsonResponse(true, 'ok', $out);
} catch (Exception $e) {
    jsonResponse(false, 'Failed to load settings', null, 500);
}
?>
