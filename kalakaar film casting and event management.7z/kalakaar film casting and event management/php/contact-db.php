<?php
// Contact Form Handler with Database Integration
define('API_MODE', true);
require_once '../config/database.php';

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(false, 'Invalid request method', null, 405);
}

try {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        jsonResponse(false, 'Invalid JSON data', null, 400);
    }
    
    // Validate required fields
    validateRequired($input, ['name', 'email', 'message']);
    
    // Sanitize input
    $data = [
        'name' => sanitize($input['name']),
        'email' => sanitize($input['email']),
        'phone' => isset($input['phone']) ? sanitize($input['phone']) : '',
        'message' => sanitize($input['message']),
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
        'status' => 'new'
    ];
    
    // Validate email
    if (!validateEmail($data['email'])) {
        jsonResponse(false, 'Invalid email address', null, 400);
    }
    
    // Validate phone if provided
    if (!empty($data['phone']) && !validatePhone($data['phone'])) {
        jsonResponse(false, 'Invalid phone number', null, 400);
    }
    
    // Insert into database
    $db = getDB();
    $contactId = $db->insert('contact_submissions', $data);
    
    // Log activity
    logActivity('CONTACT_SUBMISSION', "Name: {$data['name']}, Email: {$data['email']}");
    
    // Send email notification
    $emailSent = sendContactNotification($data);
    
    // Send auto-reply to user
    $autoReplySent = sendContactAutoReply($data);
    
    jsonResponse(true, 'Message sent successfully! We will get back to you soon.', [
        'contact_id' => $contactId,
        'email_sent' => $emailSent,
        'auto_reply_sent' => $autoReplySent
    ]);
    
} catch (Exception $e) {
    error_log("Contact form error: " . $e->getMessage());
    jsonResponse(false, 'An error occurred while processing your request', null, 500);
}

/**
 * Send email notification to admin
 */
function sendContactNotification($data) {
    $subject = 'New Contact Form Submission - ' . APP_NAME;
    
    $message = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>New Contact Form Submission</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .field { margin-bottom: 15px; }
            .label { font-weight: bold; color: #FF6B35; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>New Contact Form Submission</h2>
                <p>" . APP_NAME . "</p>
            </div>
            <div class='content'>
                <div class='field'>
                    <span class='label'>Name:</span> {$data['name']}
                </div>
                <div class='field'>
                    <span class='label'>Email:</span> {$data['email']}
                </div>";
    
    if (!empty($data['phone'])) {
        $message .= "
                <div class='field'>
                    <span class='label'>Phone:</span> {$data['phone']}
                </div>";
    }
    
    $message .= "
                <div class='field'>
                    <span class='label'>Message:</span><br>
                    " . nl2br($data['message']) . "
                </div>
                <div class='field'>
                    <span class='label'>IP Address:</span> {$data['ip_address']}
                </div>
                <div class='field'>
                    <span class='label'>Submitted:</span> " . date('Y-m-d H:i:s') . "
                </div>
            </div>
            <div class='footer'>
                <p>This email was sent from the " . APP_NAME . " website contact form.</p>
            </div>
        </div>
    </body>
    </html>";
    
    return sendEmail(APP_EMAIL, $subject, $message);
}

/**
 * Send auto-reply to user
 */
function sendContactAutoReply($data) {
    $subject = 'Thank you for contacting ' . APP_NAME;
    
    $message = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <title>Thank you for contacting " . APP_NAME . "</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #FF6B35, #F7931E); color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>Thank You for Contacting " . APP_NAME . "!</h2>
            </div>
            <div class='content'>
                <p>Dear {$data['name']},</p>
                <p>Thank you for reaching out to " . APP_NAME . ". We have received your message and our team will get back to you within 24-48 hours.</p>
                
                <p><strong>What happens next?</strong></p>
                <ul>
                    <li>Our team will review your inquiry</li>
                    <li>We'll respond to your email or call you back</li>
                    <li>We'll provide the information or assistance you need</li>
                </ul>
                
                <p>If you have any urgent questions, please feel free to call us at the number provided on our website.</p>
                
                <p>Best regards,<br>
                The " . APP_NAME . " Team</p>
            </div>
            <div class='footer'>
                <p>" . APP_NAME . "<br>
                " . APP_URL . "</p>
            </div>
        </div>
    </body>
    </html>";
    
    return sendEmail($data['email'], $subject, $message);
}
?>
